package polynomial;

public interface DeepClone<T> {
	public T deepClone();
}
